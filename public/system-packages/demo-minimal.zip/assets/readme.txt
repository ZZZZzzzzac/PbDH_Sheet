demo-minimal asset fixture
